﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calendar.Enums
{
        public enum PageEnum
        {
                Login,
                RegisterInfo,
                RegisterName,
                Calendar,
                Gallery,
                Plan
        }

        
}
