﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calendar.Model
{
    class UserInformation
    {
        private string id { get; set; }
        private string password { get; set; }
        private string email { get; set; }
        private string username { get; set; }
    }
}
