﻿using calendar.Enums;

namespace calendar.Model
{
        public class PageMove
        {
                public PageEnum pageEnum { get; set; }
                public object data { get; set; }
        }
}
