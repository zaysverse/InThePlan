﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace calendar.ViewModel
{
    class Login : ViewModelBase
    {
        public int loginId;
        public string loginPassword;


        public Login()
        {
            
        }

    }
}
