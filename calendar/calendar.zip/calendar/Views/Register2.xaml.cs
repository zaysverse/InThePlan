﻿using System.Windows.Controls;

namespace calendar.Views
{
        /// <summary>
        /// Register2.xaml에 대한 상호 작용 논리
        /// </summary>
        public partial class Register2 : UserControl
        {
                public Register2()
                {
                        InitializeComponent();
                }
        }
}
